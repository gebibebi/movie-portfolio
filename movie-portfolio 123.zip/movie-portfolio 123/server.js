const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const path = require('path');
const methodOverride = require('method-override');
const bcrypt = require('bcryptjs');
const speakeasy = require('speakeasy');
const nodemailer = require('nodemailer');
const axios = require('axios');
const { body, validationResult } = require('express-validator');
require('dotenv').config();

const movieRoutes = require('./routes/movies');
const authRoutes = require('./routes/auth');
const favoriteMoviesRoutes = require('./routes/favoriteMovies');

const app = express();
const PORT = 5400;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(methodOverride('_method'));
app.set('view engine', 'ejs');

app.use(
  session({
    secret: 'movieSecret',
    resave: false,
    saveUninitialized: true,
  })
);


mongoose
  .connect('mongodb://127.0.0.1:27017/movieDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Database connection error:', error);
  });

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, unique: true, required: true, trim: true, lowercase: true },
  password: { type: String, required: true },
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, required: true, trim: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['male', 'female', 'other'], required: true },
  role: { type: String, enum: ['admin', 'editor', 'user'], default: 'user' },
  twoFactorSecret: { type: String },
  otp_enabled: { type: Boolean, default: false },
  favoriteMovies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }],
  createdAt: { type: Date, default: Date.now },
});

const User = mongoose.models.User || mongoose.model('User', userSchema);

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  images: [String],
  genre: { type: String, required: true },
  rating: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date },
});

const Movie = mongoose.models.Movie || mongoose.model('Movie', movieSchema);

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL,
    pass: process.env.EMAIL_PASS,
  },
});

app.post(
  '/register',
  [
    body('email').isEmail().withMessage('Invalid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
    body('firstName').notEmpty().withMessage('First name is required'),
    body('lastName').notEmpty().withMessage('Last name is required'),
    body('age').isInt({ min: 1 }).withMessage('Age is required and must be a number'),
    body('gender').isIn(['male', 'female', 'other']).withMessage('Gender is required'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { name, email, password, firstName, lastName, age, gender } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);

      const twoFactorSecret = speakeasy.generateSecret({ name: 'MoviePortfolio' }).base32;

      const user = new User({
        name,
        email,
        password: hashedPassword,
        firstName,
        lastName,
        age,
        gender,
        twoFactorSecret,
        otp_enabled: false, 
      });
      await user.save();

      try {
        await transporter.sendMail({
          from: process.env.EMAIL,
          to: email,
          subject: 'Welcome to MoviePortfolio',
          text: `Hi ${firstName} ${lastName}, welcome to MoviePortfolio! Your registration is successful.`,
        });
        console.log('Email sent successfully to:', email);
      } catch (emailError) {
        console.error('Error sending email:', emailError.message);
      }

      res.status(201).send('User registered successfully');
    } catch (err) {
      console.error('Error registering user:', err);
      if (err.code === 11000) {
        return res.status(409).send('Email already exists');
      }
      res.status(500).send('Error registering user');
    }
  }
);

app.post('/login', async (req, res) => {
  try {
    const { email, password, token } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).send('Invalid email or password');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).send('Invalid email or password');
    }

    if (user.otp_enabled) {
      const isTokenValid = speakeasy.totp.verify({
        secret: user.twoFactorSecret,
        encoding: 'base32',
        token,
        window: 2,
      });

      if (!isTokenValid) {
        return res.status(401).send('Invalid 2FA token');
      }
    }

    req.session.user = user;

    if (user.role === 'admin') {
      return res.redirect('/admin');
    } else if (user.role === 'editor') {
      return res.redirect('/editor');
    } else {
      return res.redirect('/movies');
    }
  } catch (err) {
    console.error('Error logging in:', err);
    res.status(500).send('Error logging in');
  }
});

app.post('/generate-otp', async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).send('User not found');
    }

    const twoFactorSecret = speakeasy.generateSecret({ name: 'MoviePortfolio' });
    user.twoFactorSecret = twoFactorSecret.base32;
    user.otp_enabled = true;
    await user.save();

    res.status(200).json({
      base32: twoFactorSecret.base32,
      otpauth_url: twoFactorSecret.otpauth_url,
    });
  } catch (err) {
    console.error('Error generating OTP:', err.message);
    res.status(500).send('Error generating OTP');
  }
});

app.get('/import-movies', async (req, res) => {
  try {
    const response = await axios.get('https://api.themoviedb.org/3/movie/popular', {
      params: {
        api_key: process.env.TMDB_API_KEY || 'dec8521f2eefe25a34cc63512858173a',
      },
    });

    console.log('Fetched movies from TMDB:', response.data.results);

    const movies = response.data.results;

    for (const movie of movies) {
      try {
        const existingMovie = await Movie.findOne({ title: movie.title });
        if (!existingMovie) {
          await Movie.create({
            title: movie.title,
            description: movie.overview,
            images: movie.poster_path ? [`https://image.tmdb.org/t/p/w500${movie.poster_path}`] : [],
            genre: movie.genre_ids.join(', '),
            rating: movie.vote_average,
          });
          console.log(`Movie added: ${movie.title}`);
        } else {
          console.log(`Movie already exists: ${movie.title}`);
        }
      } catch (movieError) {
        console.error(`Error processing movie ${movie.title}:`, movieError.message);
      }
    }

    res.send('Фильмы успешно импортированы из TMDB!');
  } catch (error) {
    console.error('Ошибка при импорте фильмов:', error.message);
    res.status(500).send('Ошибка при импорте фильмов');
  }
});

function ensureRole(role) {
  return (req, res, next) => {
    if (!req.session.user || req.session.user.role !== role) {
      return res.status(403).send('Access denied');
    }
    next();
  };
}

app.get('/admin', ensureRole('admin'), (req, res) => {
  res.send('Welcome to the admin page');
});

app.get('/editor', ensureRole('editor'), (req, res) => {
  res.send('Welcome to the editor page');
});

app.use('/movies', movieRoutes);
app.use('/auth', authRoutes);
app.use('/favorite-movies', favoriteMoviesRoutes);

app.get('/', (req, res) => {
  res.render('index');
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
