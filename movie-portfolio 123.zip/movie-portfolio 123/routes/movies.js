const express = require('express');
const Movie = require('../models/Movie');
const User = require('../models/User');
const router = express.Router();

function ensureLoggedIn(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/auth/login');
  }
  next();
}

function ensureAdmin(req, res, next) {
  if (req.session.user.role !== 'admin') {
    return res.status(403).send('Доступ запрещен');
  }
  next();
}

function ensureEditor(req, res, next) {
  if (!['editor', 'admin'].includes(req.session.user.role)) {
    return res.status(403).send('Доступ запрещен');
  }
  next();
}

router.get('/', ensureLoggedIn, async (req, res) => {
  try {
    const movies = await Movie.find();
    const user = await User.findById(req.session.user._id).populate('favoriteMovies');
    res.render('movies', { movies, user });
  } catch (error) {
    console.error('Ошибка при получении фильмов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
});

router.post('/favorites', ensureLoggedIn, async (req, res) => {
  try {
    const { movieIds } = req.body;
    if (!Array.isArray(movieIds) || movieIds.length > 3) {
      return res.status(400).send('Вы можете выбрать до 3 любимых фильмов.');
    }

    const user = await User.findById(req.session.user._id);
    user.favoriteMovies = movieIds;
    await user.save();

    res.redirect('/movies');
  } catch (error) {
    console.error('Ошибка при сохранении любимых фильмов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
});

router.post('/', ensureLoggedIn, ensureEditor, async (req, res) => {
  const { title, description, images, genre, rating } = req.body;

  try {
    const newMovie = new Movie({
      title,
      description,
      images: images.split(',').map((img) => img.trim()),
      genre,
      rating,
    });
    await newMovie.save();
    res.redirect('/movies');
  } catch (error) {
    console.error('Ошибка при добавлении фильма:', error.message);
    res.status(500).send('Ошибка сервера');
  }
});

router.delete('/:id', ensureLoggedIn, ensureAdmin, async (req, res) => {
  try {
    await Movie.findByIdAndDelete(req.params.id);
    res.redirect('/movies');
  } catch (error) {
    console.error('Ошибка при удалении фильма:', error.message);
    res.status(500).send('Ошибка сервера');
  }
});

module.exports = router;
