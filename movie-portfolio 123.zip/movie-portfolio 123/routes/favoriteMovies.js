const express = require('express');
const FavoriteMovie = require('../models/FavoriteMovie');
const router = express.Router();


function ensureLoggedIn(req, res, next) {
  if (!req.session.user) return res.redirect('/auth/login');
  next();
}

router.get('/', ensureLoggedIn, async (req, res) => {
  try {
    const favoriteMovies = await FavoriteMovie.find({ userId: req.session.user._id });
    res.render('favoriteMovies', { favoriteMovies, user: req.session.user });
  } catch (error) {
    console.error('Ошибка при получении любимых фильмов:', error);
    res.status(500).send('Ошибка сервера');
  }
});


router.post('/', ensureLoggedIn, async (req, res) => {
  try {
    const { title, posterPath, overview } = req.body;
    const newFavoriteMovie = new FavoriteMovie({
      userId: req.session.user._id,
      title,
      posterPath,
      overview,
    });
    await newFavoriteMovie.save();
    res.status(201).send('Фильм добавлен в избранное');
  } catch (error) {
    console.error('Ошибка при добавлении фильма в избранное:', error);
    res.status(500).send('Ошибка сервера');
  }
});


router.delete('/:id', ensureLoggedIn, async (req, res) => {
  try {
    await FavoriteMovie.findByIdAndDelete(req.params.id);
    res.status(200).send('Фильм удален из избранного');
  } catch (error) {
    console.error('Ошибка при удалении фильма из избранного:', error);
    res.status(500).send('Ошибка сервера');
  }
});

module.exports = router;
