const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const speakeasy = require('speakeasy');
const nodemailer = require('nodemailer');
const { body, validationResult } = require('express-validator');
const router = express.Router();


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com', 
    pass: 'your-email-password', 
  },
});


router.get('/register', (req, res) => {
  res.render('register');
});


router.get('/login', (req, res) => {
  res.render('login');
});


router.post('/register', async (req, res) => {
  try {
    const { username, password, firstName, lastName, age, gender, role } = req.body;

    if (!username || !password || !firstName || !lastName || !age || !gender || !role) {
      return res.status(400).send('All fields are required');
    }

    if (!['admin', 'editor', 'user'].includes(role)) {
      return res.status(400).send('Invalid role');
    }

    const twoFactorSecret = speakeasy.generateSecret({ name: 'MoviePortfolio' });
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      username,
      password: hashedPassword,
      firstName,
      lastName,
      age,
      gender,
      role,
      twoFactorSecret: twoFactorSecret.base32,
    });
    await user.save();

    try {
      await transporter.sendMail({
        from: 'your-email@gmail.com',
        to: username,
        subject: 'Welcome to MoviePortfolio',
        text: 'Your registration is successful!',
      });
    } catch (emailError) {
      console.error('Error sending email:', emailError);
    }

    res.status(201).send({
      message: 'User registered successfully',
      twoFactorSecret: twoFactorSecret.base32,
      otpauth_url: twoFactorSecret.otpauth_url,
    });
  } catch (error) {
    console.error('Error registering user:', error);
    if (error.code === 11000) {
      return res.status(409).send('Username already exists');
    }
    res.status(500).send('Error registering user');
  }
});

// Обработка логина с 2FA
router.post(
  '/login',
  [
    body('username').isEmail().withMessage('Username must be a valid email'),
    body('password').notEmpty().withMessage('Password is required'),
    body('token').notEmpty().withMessage('2FA token is required'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, password, token } = req.body;

    try {
      const user = await User.findOne({ username });
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).send('Invalid username or password');
      }

      const isTokenValid = speakeasy.totp.verify({
        secret: user.twoFactorSecret,
        encoding: 'base32',
        token,
        window: 2,
      });

      if (!isTokenValid) {
        return res.status(401).send('Invalid 2FA token');
      }

      req.session.user = {
        id: user._id,
        username: user.username,
        role: user.role,
      };

      if (user.role === 'admin') {
        res.redirect('/admin');
      } else if (user.role === 'editor') {
        res.redirect('/editor');
      } else {
        res.redirect('/movies');
      }
    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).send('Error logging in');
    }
  }
);

module.exports = router;
