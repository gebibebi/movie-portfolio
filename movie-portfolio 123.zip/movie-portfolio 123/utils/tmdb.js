const axios = require('axios');

const TMDB_API_KEY = 'dec8521f2eefe25a34cc63512858173a'; 
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

const searchTMDBMovies = async (query) => {
  try {
    const response = await axios.get(`${TMDB_BASE_URL}/search/movie`, {
      params: {
        api_key: TMDB_API_KEY,
        query, 
      },
    });
    return response.data.results; 
  } catch (err) {
    console.error('Ошибка при запросе к TMDB API:', err.message);
    throw new Error('Не удалось получить данные из TMDB API');
  }
};


const getTMDBMovieDetails = async (id) => {
  try {
    const response = await axios.get(`${TMDB_BASE_URL}/movie/${id}`, {
      params: {
        api_key: TMDB_API_KEY,
      },
    });
    return response.data; 
  } catch (err) {
    console.error('Ошибка при запросе деталей фильма из TMDB API:', err.message);
    throw new Error('Не удалось получить данные из TMDB API');
  }
};

module.exports = { searchTMDBMovies, getTMDBMovieDetails };
