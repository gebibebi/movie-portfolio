const nodemailer = require('nodemailer');

// Настройка транспортера для MailHog
const transporter = nodemailer.createTransport({
  host: '127.0.0.1', // Локальный хост MailHog
  port: 1025,        // Порт MailHog для SMTP
  secure: false,     // Отключение TLS
});

/**
 * Функция для отправки почты
 * @param {string} to - Адрес получателя
 * @param {string} subject - Тема письма
 * @param {string} text - Текст письма
 */
const sendMail = async (to, subject, text) => {
  const mailOptions = {
    from: 'test@example.com', // Адрес отправителя
    to,                       // Адрес получателя
    subject,                  // Тема письма
    text,                     // Текст письма
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info);
  } catch (error) {
    console.error('Error sending email:', error);
  }
};

module.exports = sendMail;
