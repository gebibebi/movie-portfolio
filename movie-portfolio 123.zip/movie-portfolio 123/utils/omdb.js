const axios = require('axios');

const OMDB_API_KEY = '323cd66f'; 
const OMDB_BASE_URL = 'http://www.omdbapi.com/';

const searchOMDBMovies = async (query) => {
  try {
    const response = await axios.get(OMDB_BASE_URL, {
      params: {
        apikey: OMDB_API_KEY,
        s: query,
      },
    });
    if (response.data.Response === 'True') {
      return response.data.Search; 
    }
    return [];
  } catch (err) {
    console.error('Ошибка при запросе к OMDB API:', err.message);
    throw new Error('Не удалось получить данные из OMDB API');
  }
};


const getOMDBMovieDetails = async (id) => {
  try {
    const response = await axios.get(OMDB_BASE_URL, {
      params: {
        apikey: OMDB_API_KEY,
        i: id,
      },
    });
    if (response.data.Response === 'True') {
      return response.data;
    }
    return null;
  } catch (err) {
    console.error('Ошибка при запросе деталей фильма из OMDB API:', err.message);
    throw new Error('Не удалось получить данные из OMDB API');
  }
};

module.exports = { searchOMDBMovies, getOMDBMovieDetails };
